﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListEncadeada
{
    public partial class AlocacaoMemoria : Form
    {
        public AlocacaoMemoria()
        {
            InitializeComponent();
            Inicializa(ref inicio);
        }
        const string msgNaoEncontrado = "PID não encontrado!";

        class tp_no
        {
            public int pid;
            public string status;
            public int tamanhoAlocacao;
            public tp_no prox;
        }
        string msSucesso = "Ação realizada com sucesso";
        tp_no inicio;
        tp_no atual, anterior;
        // Função que inicializa
        void Inicializa(ref tp_no inicio)
        {
            inicio = null;
            atual = null;
            anterior = null;
        }
        // Incluir
        void Insere(ref tp_no inicio, tp_no no)
        {
            if (inicio != null) no.prox = inicio;
            inicio = no;
        }
        public void btGravarInclusao_Click(object sender, EventArgs e)
        {
            tp_no node = new tp_no(); //alocar memória, cria uma instância
            node.pid = Convert.ToInt32(tbPIDInclusao.Text);
            node.status = "Processo";
            node.tamanhoAlocacao = Convert.ToInt32(tbTamanhoAlocacaoInclusao.Text);
            node.prox = null;
            Insere(ref inicio, node);
            tbPIDInclusao.Clear();
            tbTamanhoAlocacaoInclusao.Clear();
            tbPIDInclusao.Focus();

        }
        //Incluir First-Fit
        void InsereFirstFit(ref tp_no inicio, tp_no no)
        {
            if (inicio == null)
                inicio = no;
            else { 
                int i = 0;
                anterior = null;
                atual = inicio; //auxiliar para não sobrescrever
                while (atual != null)
                {
                    if (atual.status == "Livre" && atual.tamanhoAlocacao > no.tamanhoAlocacao)
                    {
                        anterior.prox = no;
                        atual.tamanhoAlocacao -= no.tamanhoAlocacao;
                        no.prox = atual;
                        i = 1;
                        break;
                    }
                    else if (atual.status == "Livre" && atual.tamanhoAlocacao == no.tamanhoAlocacao)
                    {
                        anterior.prox = no;
                        no.prox = atual.prox;
                        atual.prox = null;
                        i = 1;
                        break;
                    }
                    anterior = atual;
                    atual = atual.prox;
                }
                if (i == 0) InsereNoFim(ref inicio, no);
            }
        }
        private void btGravarFirstFit_Click(object sender, EventArgs e)
        {
            tp_no node = new tp_no(); //alocar memória, cria uma instância
            node.pid = Convert.ToInt32(tbPIDInclusao.Text);
            node.status = "Processo";
            node.tamanhoAlocacao = Convert.ToInt32(tbTamanhoAlocacaoInclusao.Text);
            node.prox = null;
            InsereFirstFit(ref inicio, node);

            tbPIDInclusao.Clear();
            tbTamanhoAlocacaoInclusao.Clear();
            tbPIDInclusao.Focus();
        }

        void InsereNoFim(ref tp_no inicio, tp_no no)
        {
            if (inicio != null)
            {
                atual = inicio; //auxiliar para não sobrescrever
                while (atual.prox != null)
                    atual = atual.prox;
                atual.prox = no;
            }
            else
                inicio = no;
        }

        private void btGravaNoFim_Click(object sender, EventArgs e)
        {
            tp_no node = new tp_no(); //alocar memória, cria uma instância
            node.pid = Convert.ToInt32(tbPIDInclusao.Text);
            node.status = "Processo";
            node.tamanhoAlocacao = Convert.ToInt32(tbTamanhoAlocacaoInclusao.Text);
            node.prox = null;
            InsereNoFim(ref inicio, node);

            tbPIDInclusao.Clear();
            tbTamanhoAlocacaoInclusao.Clear();
            tbPIDInclusao.Focus();
        }

        //busca sequencial
        void Consulta(int pid)
        {
            anterior = null;
            atual = inicio; //auxiliar para não sobrescrever
            while (atual != null && pid != atual.pid)
            {
                anterior = atual;
                atual = atual.prox;
            }
        }
        //liberar memória
        private void btConsultaPIDLiberarOnClick(object sender, EventArgs e)
        {
            int pid = Convert.ToInt32(tbPIDConsultaCompactar.Text);
            Consulta(pid);

            if (atual != null)
            {
                tbPIDAlteracao.Text = Convert.ToString(atual.pid);
                tbTamanhoAlteracao.Text = Convert.ToString(atual.tamanhoAlocacao);
            }
            else
                MessageBox.Show(msgNaoEncontrado);
        }
        private void btLiberarMemoria_Click(object sender, EventArgs e)
        {
            int pid = Convert.ToInt32(tbPIDConsultaCompactar.Text);
            Consulta(pid);

            if (atual != null)
            {
                atual.pid = -1;
                atual.status = "Livre";
                MessageBox.Show(msSucesso); 
            }
            else
                MessageBox.Show(msgNaoEncontrado);
            tbPIDAlteracao.Clear();
            tbTamanhoAlteracao.Clear();
            tbPIDConsultaCompactar.Focus();
        }
        //exibir
        private void btExibeRegistros_Click(object sender, EventArgs e)
        {
            lbExibeRegistros.Items.Clear();
            Exibir();

        }
        void Exibir()
        {
            atual = inicio;
            while (atual != null)
            {
                if (atual.status == "Processo")
                {
                    lbExibeRegistros.Items.Add($" PID: {atual.pid}.");
                    lbExibeRegistros.Items.Add($" Tamanho alocado: {atual.tamanhoAlocacao}kb.");
                    lbExibeRegistros.Items.Add(" ");
                }
                else
                {
                    lbExibeRegistros.Items.Add($" Estado: {atual.status}.");
                    lbExibeRegistros.Items.Add($" Tamanho desalocado: {atual.tamanhoAlocacao}kb.");
                    lbExibeRegistros.Items.Add(" ");
                }
                atual = atual.prox;
            }
        }
        //compactar áreas adjacentes
        private void btCompactarAdj_Click(object sender, EventArgs e)
        {
            Compactar(ref inicio);
        }
        void Compactar(ref tp_no inicio)
        {
            anterior = null;
            atual = inicio;
            while (atual != null)
            {
                anterior = atual;
                atual = atual.prox;
                if (anterior.status == "Livre" && anterior.status == atual.status)
                {
                    anterior.tamanhoAlocacao += atual.tamanhoAlocacao;
                    anterior.prox = atual.prox;
                    atual.prox = null;
                    Compactar(ref inicio);
                    MessageBox.Show(msSucesso);
                }
                else
                    MessageBox.Show("Não há fragmentos livre adjacentes para compactação!");
            }
        }
        private void btEsvaziar_Click(object sender, EventArgs e)
        {
            //inicio = null;
            while (inicio != null)
            {
                atual = inicio;
                inicio = inicio.prox;
                atual.prox = null;
            }
            MessageBox.Show(msSucesso); 
        }
    }
}
